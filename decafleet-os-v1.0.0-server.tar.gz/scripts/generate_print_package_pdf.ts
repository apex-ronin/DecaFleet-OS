/**
 * DecaFleet-OS: Master Print Package Generator for Natalie & Jay
 * 
 * Generates:
 *  1. docs/DecaFleet_Master_Print_Package_Natalie_and_Jay.html
 *  2. docs/DecaFleet_Master_Print_Package_Natalie_and_Jay.pdf
 *  3. shared/reports/DecaFleet_Master_Print_Package_Natalie_and_Jay.pdf
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const HTML_CONTENT = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DecaFleet-OS: Executive Print Package — Prepared for Natalie & Jay</title>
  <style>
    @page {
      size: letter;
      margin: 14mm 14mm 14mm 14mm;
      @bottom-left {
        content: "DecaFleet-OS v1.0.0 · Prepared for Natalie & Jay";
        font-size: 7.5pt;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #64748b;
      }
      @bottom-right {
        content: "Page " counter(page) " of " counter(pages);
        font-size: 7.5pt;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #64748b;
      }
    }
    *, *:before, *:after {
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.45;
      font-size: 10pt;
      margin: 0;
      padding: 0;
    }
    .page {
      page-break-after: always;
      position: relative;
    }
    .page:last-child {
      page-break-after: avoid;
    }
    
    /* Cover Page */
    .cover-page {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 980px;
      padding: 30px 20px 20px 20px;
      page-break-after: always;
      border: 2px solid #0f172a;
      border-radius: 8px;
      background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
    }
    .cover-top {
      border-bottom: 3px solid #0f172a;
      padding-bottom: 20px;
    }
    .cover-badge {
      display: inline-block;
      background: #0f172a;
      color: #10b981;
      padding: 4px 12px;
      font-size: 8.5pt;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
      border-radius: 4px;
      font-family: monospace;
      margin-bottom: 12px;
    }
    .cover-title {
      font-size: 26pt;
      font-weight: 900;
      color: #0f172a;
      line-height: 1.15;
      margin: 0 0 10px 0;
      letter-spacing: -0.5px;
    }
    .cover-subtitle {
      font-size: 13pt;
      color: #334155;
      font-weight: 600;
      line-height: 1.4;
      margin: 0;
    }
    .cover-middle {
      padding: 30px 0;
    }
    .recipient-card {
      background: #ffffff;
      border: 2px solid #cbd5e1;
      border-radius: 8px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    }
    .recipient-label {
      font-size: 9pt;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-weight: 800;
      color: #047857;
      margin-bottom: 6px;
    }
    .recipient-names {
      font-size: 20pt;
      font-weight: 900;
      color: #0f172a;
      margin-bottom: 6px;
    }
    .recipient-desc {
      font-size: 10pt;
      color: #475569;
      line-height: 1.4;
    }
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 12px;
    }
    .summary-box {
      border: 1px solid #cbd5e1;
      background: #ffffff;
      padding: 12px;
      border-radius: 6px;
      text-align: center;
    }
    .summary-val {
      font-size: 14pt;
      font-weight: 800;
      color: #0f172a;
      font-family: monospace;
    }
    .summary-lbl {
      font-size: 7.5pt;
      text-transform: uppercase;
      font-weight: 700;
      color: #64748b;
      margin-top: 3px;
    }
    .cover-bottom {
      border-top: 1px solid #cbd5e1;
      padding-top: 15px;
      display: flex;
      justify-content: space-between;
      font-size: 8.5pt;
      color: #64748b;
      font-family: monospace;
    }

    /* Standard Headers & Typography */
    .header-bar {
      border-bottom: 2px solid #0f172a;
      padding-bottom: 6px;
      margin-bottom: 14px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .brand {
      font-size: 15pt;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.3px;
    }
    .brand-tag {
      font-size: 7.5pt;
      text-transform: uppercase;
      font-weight: 700;
      color: #047857;
      letter-spacing: 0.5px;
    }
    .doc-meta {
      text-align: right;
      font-size: 8pt;
      color: #475569;
      font-family: monospace;
    }
    h1 {
      font-size: 14pt;
      font-weight: 800;
      margin: 0 0 6px 0;
      color: #0f172a;
      letter-spacing: -0.2px;
    }
    h2 {
      font-size: 11pt;
      font-weight: 700;
      color: #0f172a;
      margin: 12px 0 6px 0;
      padding-bottom: 3px;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    h3 {
      font-size: 9.5pt;
      font-weight: 700;
      color: #1e293b;
      margin: 8px 0 4px 0;
    }
    p {
      margin: 0 0 6px 0;
      color: #334155;
      font-size: 9pt;
      line-height: 1.4;
    }
    .badge {
      display: inline-block;
      padding: 1.5px 5px;
      font-size: 7pt;
      font-weight: 700;
      text-transform: uppercase;
      border-radius: 3px;
      font-family: monospace;
    }
    .badge-red { background: #fee2e2; color: #991b1b; border: 1px solid #f87171; }
    .badge-orange { background: #ffedd5; color: #9a3412; border: 1px solid #fb923c; }
    .badge-green { background: #dcfce7; color: #166534; border: 1px solid #4ade80; }
    .badge-blue { background: #dbeafe; color: #1e40af; border: 1px solid #60a5fa; }
    .badge-slate { background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; }

    .callout {
      background: #f8fafc;
      border-left: 3.5px solid #0f172a;
      padding: 8px 10px;
      margin: 8px 0;
      border-radius: 0 5px 5px 0;
      font-size: 8.5pt;
      line-height: 1.35;
    }
    .callout-alert {
      background: #fef2f2;
      border-left-color: #dc2626;
      color: #991b1b;
    }
    .callout-success {
      background: #f0fdf4;
      border-left-color: #16a34a;
      color: #166534;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin: 6px 0 10px 0;
      font-size: 8pt;
    }
    th {
      background: #f1f5f9;
      color: #0f172a;
      text-align: left;
      padding: 5px 7px;
      font-weight: 700;
      border: 1px solid #cbd5e1;
      font-size: 7.8pt;
    }
    td {
      padding: 4px 7px;
      border: 1px solid #e2e8f0;
      vertical-align: top;
      line-height: 1.3;
    }
    tr:nth-child(even) td {
      background: #f8fafc;
    }
    code, pre {
      font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
      font-size: 7.8pt;
    }
    code {
      background: #f1f5f9;
      padding: 1px 3px;
      border-radius: 3px;
      color: #0f172a;
    }
    pre {
      background: #0f172a;
      color: #f8fafc;
      padding: 7px 9px;
      border-radius: 4px;
      overflow-x: auto;
      margin: 5px 0;
      line-height: 1.25;
      font-size: 7.5pt;
    }
    .day-card {
      border: 1px solid #cbd5e1;
      border-radius: 5px;
      padding: 8px 10px;
      margin-bottom: 8px;
      background: #ffffff;
      page-break-inside: avoid;
    }
    .day-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 4px;
      border-bottom: 1px solid #f1f5f9;
      padding-bottom: 3px;
    }
    .day-title {
      font-weight: 800;
      font-size: 9.5pt;
      color: #0f172a;
    }
    .day-hours {
      font-size: 7.5pt;
      font-family: monospace;
      font-weight: 700;
      color: #475569;
      background: #f1f5f9;
      padding: 1px 5px;
      border-radius: 3px;
    }
    .checklist {
      list-style: none;
      padding: 0;
      margin: 4px 0 0 0;
    }
    .checklist li {
      position: relative;
      padding-left: 16px;
      margin-bottom: 3px;
      font-size: 8.2pt;
      color: #334155;
      line-height: 1.3;
    }
    .checklist li:before {
      content: "☐";
      position: absolute;
      left: 0;
      top: -1px;
      font-size: 9pt;
      color: #64748b;
    }
    .checklist li.checked:before {
      content: "☑";
      color: #059669;
    }
  </style>
</head>
<body>

  <!-- ========================================================================= -->
  <!-- COVER PAGE: PREPARED FOR NATALIE & JAY                                    -->
  <!-- ========================================================================= -->
  <div class="page cover-page">
    <div class="cover-top">
      <div class="cover-badge">Sovereign 10-Bot Swarm Execution Platform</div>
      <div class="cover-title">DecaFleet-OS: Master Execution Package</div>
      <div class="cover-subtitle">Complete Operational Instructions, Revenue Roadmap &amp; Field Manual</div>
    </div>

    <div class="cover-middle">
      <div class="recipient-card">
        <div class="recipient-label">Dedicated Operational Package Prepared Specifically For</div>
        <div class="recipient-names">Natalie &amp; Jay</div>
        <div class="recipient-desc">
          <strong>Founders &amp; Swarm Executive Directors</strong> · This document constitutes your complete turnkey field operations manual. It binds the <strong>4-Stage Sovereign Master Plan ($0 to $35k+ MRR)</strong> with the <strong>Day-by-Day Stage 1 Execution Schedule</strong>, pre-approved outreach tear-sheets, objection-handling scripts, and statutory legal authorities.
        </div>
      </div>

      <div class="summary-grid">
        <div class="summary-box">
          <div class="summary-val">$149 &rarr; $399/mo</div>
          <div class="summary-lbl">Stage 1 Commercial Pricing</div>
        </div>
        <div class="summary-box">
          <div class="summary-val">97.0%</div>
          <div class="summary-lbl">Gross Margin</div>
        </div>
        <div class="summary-box">
          <div class="summary-val">&lt; 20h / Week</div>
          <div class="summary-lbl">Human Operator Ceiling</div>
        </div>
        <div class="summary-box">
          <div class="summary-val">Zero-Login</div>
          <div class="summary-lbl">100% Sunshine Portals</div>
        </div>
        <div class="summary-box">
          <div class="summary-val">jev-latest</div>
          <div class="summary-lbl">System One Decision Gate</div>
        </div>
        <div class="summary-box">
          <div class="summary-val">$4,300+ MRR</div>
          <div class="summary-lbl">Gate 1 Target Milestone</div>
        </div>
      </div>
    </div>

    <div class="cover-bottom">
      <div>CHIEF ARCHITECT: <strong>GEM (APEX-RONIN SWARM)</strong></div>
      <div>DOCTRINE: <strong>"TRUST BUT VERIFY"</strong></div>
      <div>DATE: <strong>NOVEMBER 4, 2026 · v1.0.0</strong></div>
    </div>
  </div>

  <!-- ========================================================================= -->
  <!-- PAGE 2: PART I — MASTER STRATEGIC ARCHITECTURE & 4-STAGE ROADMAP          -->
  <!-- ========================================================================= -->
  <div class="page">
    <div class="header-bar">
      <div>
        <div class="brand">DecaFleet-OS 🚀</div>
        <div class="brand-tag">Part I: Master Strategic Architecture</div>
      </div>
      <div class="doc-meta">
        <div>EXECUTIVE DOSSIER</div>
        <div>PREPARED FOR: <strong>NATALIE & JAY</strong></div>
        <div>VERSION 1.0.0</div>
      </div>
    </div>

    <h1>Part I: The 4-Stage Sovereign Revenue Trajectory ($0 to $35,000+ MRR)</h1>
    <p>
      Natalie & Jay: DecaFleet-OS is engineered to solve the single largest vulnerability in automated services: <em>premature horizontal scaling and platform ban risk</em>. By enforcing the <strong>Zero-Credential / No-Login Default</strong> and the <strong>60-Day Trigger Blitz</strong>, operations remain strictly within a single-operator, 20h/week human envelope.
    </p>

    <h2>1. The 4-Stage Sovereign Revenue Sequence</h2>
    <table>
      <thead>
        <tr>
          <th>Stage</th>
          <th>Timeline</th>
          <th>Service Line & Handbook</th>
          <th>Entry Wedge</th>
          <th>Core Retainer</th>
          <th>Margin</th>
          <th>Target Roster</th>
          <th>Target MRR</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Stage 1 (Live)</strong></td>
          <td>Days 1–30</td>
          <td><strong>C1: Sub Radar</strong> (CSLB, TDLR, DBPR License, Bond &amp; WC Monitor)</td>
          <td><strong>$149</strong> (40-Sub Audit)</td>
          <td><strong>$399/mo</strong></td>
          <td><strong>97.0%</strong></td>
          <td>10 GCs + Audits</td>
          <td><strong>$4,300+ MRR</strong></td>
        </tr>
        <tr>
          <td><strong>Stage 2</strong></td>
          <td>Days 31–60</td>
          <td><strong>P1: Trade Map Desk</strong> + <strong>P3: Funnel &amp; Ad Metadata Desk</strong></td>
          <td><strong>$199</strong> / <strong>$75</strong> Audit</td>
          <td><strong>$449/mo</strong> + $900/mo</td>
          <td><strong>96.0%</strong></td>
          <td>25 Sub Radar + 12 Trade Map</td>
          <td><strong>$15,000+ MRR</strong></td>
        </tr>
        <tr>
          <td><strong>Stage 3</strong></td>
          <td>Days 61–90</td>
          <td><strong>P2: Catalog Exception Desk</strong> (500–10k SKU Merchant Diffs)</td>
          <td><strong>$299</strong> (500-SKU Triage)</td>
          <td><strong>$1,000–$2,200/mo</strong></td>
          <td><strong>94.5%</strong></td>
          <td>Contractors + 10 E-Com Brands</td>
          <td><strong>$25,000+ MRR</strong></td>
        </tr>
        <tr>
          <td><strong>Stage 4</strong></td>
          <td>Day 90+</td>
          <td><strong>C2: Fleet Collision Lab</strong> + <strong>C3: Seat Sniper / GovDesk</strong></td>
          <td><strong>$499</strong> (Collision Audit)</td>
          <td><strong>$1,800/mo</strong> + $400/mo</td>
          <td><strong>95.8%</strong></td>
          <td>Multi-Vertical Enterprise</td>
          <td><strong>$32,500–$40k+ MRR</strong></td>
        </tr>
      </tbody>
    </table>

    <div class="callout callout-success">
      <strong>The Architect's Rule for Natalie & Jay:</strong> <em>Why Stage 1 and Stage 2 share the exact same buyer list.</em> Never launch a second business to a brand-new ICP on Day 30. By cross-selling <strong>Trade Map Desk ($449/mo)</strong> to the <em>exact same General Contractors</em> already paying for Sub Radar, you lift client LTV from $399/mo to $848/mo with <strong>Zero Customer Acquisition Cost (CAC)</strong>.
    </div>

    <h2>2. Velocity Models: Blitz vs. Stress Test vs. Annual Baseline</h2>
    <table>
      <thead>
        <tr>
          <th>Evaluation Dimension</th>
          <th>60-Day Trigger Blitz (Recommended)</th>
          <th>12-Day Stress Test Mode</th>
          <th>Legacy 12-Month Annual Plan</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Expansion Trigger</strong></td>
          <td>Strict Metric Gates (&ge; 3 Retainers, 0 DOM errors)</td>
          <td>Calendar Force (Days 1, 4, 7, 10)</td>
          <td>Quarterly Corporate Reviews</td>
        </tr>
        <tr>
          <td><strong>Operator Weekly Hours</strong></td>
          <td><strong>8.5h to 15.0h / week</strong> (Healthy headroom)</td>
          <td><strong>36.5h / week</strong> (Circuit Breaker Tripped)</td>
          <td>4.0h to 10.0h / week</td>
        </tr>
        <tr>
          <td><strong>Context Switching Risk</strong></td>
          <td>1 ICP at a time (GCs &rarr; E-commerce &rarr; Devs)</td>
          <td>3 ICPs simultaneously (High failure rate)</td>
          <td>Highly serialized</td>
        </tr>
        <tr>
          <td><strong>Jev-AI System One Routing</strong></td>
          <td><strong>Tier 2 Co-Sign Batch</strong> (P = 92%, 1-Click)</td>
          <td><strong>Tier 3 Escalation Gridlock</strong> (Confidence &lt; 0.60)</td>
          <td>Tier 2 Co-Sign Batch</td>
        </tr>
        <tr>
          <td><strong>Time to $10,000 MRR</strong></td>
          <td><strong>Day 45–50</strong></td>
          <td>Failed due to operator capacity collapse</td>
          <td>Month 5 (Day 150)</td>
        </tr>
      </tbody>
    </table>

    <h2>3. Expansion Gate Diagnostic & Tripwire Criteria</h2>
    <p>Before Natalie or Jay unlocks the next stage, the current vertical must mathematically clear these gates:</p>
    <ul>
      <li><strong>Gate 1 (Stage 1 &rarr; Stage 2):</strong> &ge; 3 active paying GC retainers ($399/mo) + 2 consecutive weekly delivery cycles with <strong>0 unhandled DOM selector errors</strong> + ongoing maintenance takes <strong>&lt; 4 hours/week</strong>.</li>
      <li><strong>Gate 2 (Stage 2 &rarr; Stage 3):</strong> Minimum $15,000 combined MRR + Sub Radar &amp; Trade Map running autonomously + combined operator load <strong>&le; 12 hours/week</strong>.</li>
      <li><strong>Gate 3 (Stage 3 &rarr; Stage 4):</strong> Minimum $25,000 MRR + merchant feed pipelines automated via DBOS step checkpoints + total load <strong>&le; 16 hours/week</strong>.</li>
    </ul>
  </div>

  <!-- ========================================================================= -->
  <!-- PAGE 3: PART II — 10-BOT WORKSTATION TOPOLOGY & VM TIME-MULTIPLEXING     -->
  <!-- ========================================================================= -->
  <div class="page">
    <div class="header-bar">
      <div>
        <div class="brand">DecaFleet-OS 🚀</div>
        <div class="brand-tag">Part II: Swarm Fleet Architecture</div>
      </div>
      <div class="doc-meta">
        <div>FLEET & VM TOPOLOGY</div>
        <div>PREPARED FOR: <strong>NATALIE & JAY</strong></div>
        <div>CAPACITY: 38,400 MIN/MO</div>
      </div>
    </div>

    <h1>Part II: 10-Bot Swarm Allocation &amp; 24-Hour VM Multiplexing</h1>
    <p>
      Natalie & Jay: DecaFleet-OS operates 10 concurrent browser lanes on a single workstation (8 active worker lanes + 2 hot-spare failover lanes). To maximize hardware efficiency without crossing browser limits, the fleet runs on a <strong>24-Hour Time-Multiplexing Schedule</strong>.
    </p>

    <h2>1. 10-Bot Worker Lane Assignments</h2>
    <table>
      <thead>
        <tr>
          <th>Lane</th>
          <th>Bot ID & Role</th>
          <th>Primary Operational Task</th>
          <th>Approval Boundary</th>
          <th>Durable DBOS Step</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Lane 01</strong></td>
          <td><code>BoardScout-01</code></td>
          <td>California CSLB contractor registry DOM scraper (License, Bond, WC)</td>
          <td>Autonomous Scrape</td>
          <td><code>ckpt_cslb_scrape</code></td>
        </tr>
        <tr>
          <td><strong>Lane 02</strong></td>
          <td><code>BoardScout-02</code></td>
          <td>Texas TDLR electrician &amp; HVAC registry DOM scraper</td>
          <td>Autonomous Scrape</td>
          <td><code>ckpt_tdlr_scrape</code></td>
        </tr>
        <tr>
          <td><strong>Lane 03</strong></td>
          <td><code>BoardScout-03</code></td>
          <td>Florida DBPR commercial contractor registry DOM scraper</td>
          <td>Autonomous Scrape</td>
          <td><code>ckpt_dbpr_scrape</code></td>
        </tr>
        <tr>
          <td><strong>Lane 04</strong></td>
          <td><code>BoardScout-04</code></td>
          <td>Multi-State Sunshine Overflow &amp; Google Maps Citation Inspector</td>
          <td>Autonomous Scrape</td>
          <td><code>ckpt_overflow_scrape</code></td>
        </tr>
        <tr>
          <td><strong>Lane 05</strong></td>
          <td><code>DiffEngine-01</code></td>
          <td>Delta comparison: Baseline state records vs. 04:00 AM live scrape</td>
          <td>Autonomous Diff</td>
          <td><code>ckpt_diff_compute</code></td>
        </tr>
        <tr>
          <td><strong>Lane 06</strong></td>
          <td><code>DiffEngine-02</code></td>
          <td>Cross-reference verification against carrier databases &amp; policy numbers</td>
          <td>Autonomous Diff</td>
          <td><code>ckpt_carrier_crossref</code></td>
        </tr>
        <tr>
          <td><strong>Lane 07</strong></td>
          <td><code>Dossier-01</code></td>
          <td>Generates deliverable $149 40-Sub Forensic Liability Audit Packets</td>
          <td>Autonomous Render</td>
          <td><code>ckpt_dossier_gen</code></td>
        </tr>
        <tr>
          <td><strong>Lane 08</strong></td>
          <td><code>Dossier-02</code></td>
          <td>Compiles superintendent stop-work notices &amp; tear-sheet summaries</td>
          <td>Autonomous Render</td>
          <td><code>ckpt_tearsheet_render</code></td>
        </tr>
        <tr>
          <td><strong>Lane 09</strong></td>
          <td><code>Dispatch-01</code></td>
          <td>Stages outbound breach alerts &amp; pitches into Jev-AI System One Gate</td>
          <td><strong>Tier-2 Gate Co-Sign</strong></td>
          <td><code>ckpt_dispatch_stage</code></td>
        </tr>
        <tr>
          <td><strong>Lane 10</strong></td>
          <td><code>Supervisor-01</code></td>
          <td>Hot-Spare failover sentinel, memory recycling &amp; Stagehand self-healer</td>
          <td>Autonomous Sentinel</td>
          <td><code>ckpt_sentinel_monitor</code></td>
        </tr>
      </tbody>
    </table>

    <h2>2. 24-Hour VM Cluster Time-Multiplexing Schedule</h2>
    <table>
      <thead>
        <tr>
          <th>Shift Window</th>
          <th>Active Services</th>
          <th>Fleet Operations &amp; Hardware Allocation</th>
          <th>Why This Window</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Night Shift</strong><br>00:00 – 06:00 EST</td>
          <td><strong>Sub Radar (C1)</strong><br><strong>Seat Sniper (C3)</strong></td>
          <td>8 lanes execute CSLB, TDLR, DBPR registry polls and municipal inspection window releases. Output: 04:00 AM daily diff digests.</td>
          <td>Government state licensing portals refresh batch databases at midnight. Lowest server traffic &amp; zero ban risk.</td>
        </tr>
        <tr>
          <td><strong>Morning Shift</strong><br>06:00 – 14:00 EST</td>
          <td><strong>Catalog Desk (P2)</strong><br><strong>Trade Map Desk (P1)</strong></td>
          <td>Audits Shopify Plus &amp; Merchant Center feeds; executes 65-directory NAP citation sweeps for trade contractors.</td>
          <td>Catches catalog and ad pixel errors before daily digital advertising budgets peak.</td>
        </tr>
        <tr>
          <td><strong>Afternoon Shift</strong><br>14:00 – 22:00 EST</td>
          <td><strong>Collision Lab (C2)</strong><br><strong>Funnel Desk (P3)</strong></td>
          <td>Runs 8-worker concurrent race condition test suites on customer staging sites; audits unauthenticated checkouts.</td>
          <td>Aligns with enterprise SaaS engineering sprints and staging deployment testing hours.</td>
        </tr>
        <tr>
          <td><strong>Maintenance</strong><br>22:00 – 00:00 EST</td>
          <td><strong>Supervisor-01</strong></td>
          <td>DBOS checkpoint compaction, log rotation, memory garbage collection, and Stagehand DOM selector self-healing.</td>
          <td>Zero client deliverables due; ensures 99.9% uptime for the next day's 00:00 AM cycle.</td>
        </tr>
      </tbody>
    </table>

    <h2>3. Jev-AI (jev-latest) Constitutional Gate Formula</h2>
    <p>
      Every outbound email, client compliance alert, and audit packet is evaluated across 6 atomic questions. Natalie & Jay retain final 1-click authority in the <strong>Approval Gate</strong>:
    </p>
    <pre><code>Composite Liability Risk = 0.45*(non_delegable) + 0.30*(blast_radius/2.0) + 0.15*(1 - evidence) + 0.10*(1 - zero_login)

• Tier 1 (Auto-Dispatch): P >= 0.85, blast_radius <= 0.45, composite_risk <= 0.15 (Internal staging traces, read-only diffs)
• Tier 2 (Co-Sign Batch): P >= 0.70, evidence.noul >= 0.80, composite_risk <= 0.50 (Verified compliance alerts, $149 audit packets)
• Tier 3 (Hard Human Lock): non_delegable >= 0.30 or P < 0.60 (Municipal bid signatures, 2FA tokens, legal disputes)</code></pre>
  </div>

  <!-- ========================================================================= -->
  <!-- PAGE 4: PART III — STAGE 1 WEEK 1 STEP-BY-STEP INSTRUCTION SHEET          -->
  <!-- ========================================================================= -->
  <div class="page">
    <div class="header-bar">
      <div>
        <div class="brand">DecaFleet-OS 🚀</div>
        <div class="brand-tag">Part III: Stage 1 Week 1 Field Manual</div>
      </div>
      <div class="doc-meta">
        <div>WEEK 1: DAYS 1 – 7</div>
        <div>PREPARED FOR: <strong>NATALIE & JAY</strong></div>
        <div>OPERATOR BUDGET: 8.5 HOURS</div>
      </div>
    </div>

    <h1>Part III: Week 1 Operational Instruction Sheet (Nov 2 – Nov 8, 2026)</h1>
    <p>
      Natalie & Jay: This is your exact operational playbook for Week 1. Follow each step in order; check off each box as you complete the action.
    </p>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAY 1 (MONDAY): Pre-Flight Audit &amp; California Red Breach Staging</span>
        <span class="day-hours">OPERATOR TIME: 2.0 HOURS</span>
      </div>
      <ul class="checklist">
        <li class="checked"><strong>Step 1.1 — Terminal Health Verification:</strong> Open terminal in workspace root. Run <code>npm test</code> (verify 8/8 tests pass) and <code>npm run lint</code> (verify 0 TypeScript compiler errors).</li>
        <li class="checked"><strong>Step 1.2 — Live Registry Scrape:</strong> Run <code>npm run audit:sub-radar</code>. This fires <code>BoardScout-01..04</code> across CSLB, TDLR, and DBPR, writing <code>shared/data/registry_raw.json</code>.</li>
        <li class="checked"><strong>Step 1.3 — Delta Diff Execution:</strong> Confirm <code>DiffEngine-01..02</code> isolates 6 active breaches in <code>shared/data/compliance_breaches.json</code> ($1,820,000 total exposure).</li>
        <li class="checked"><strong>Step 1.4 — Jev-AI Gate Check:</strong> Run <code>npm run audit:master-plan</code>. Verify Stage 1 alerts clear <code>TIER_2_CO_SIGN</code> ($P = 0.92$, Risk = $0.16$).</li>
        <li><strong>Step 1.5 — Review Staged California Red Breaches:</strong> Confirm details for target GC Sierra Pacific Commercial Builders:
          <br>&bull; <code>SUB-01</code> <strong>Sierra Structural Concrete LLC</strong>: $25k Surety Bond lapsed &rarr; License SUSPENDED (§ 7071.6) ($420,000 exposure).
          <br>&bull; <code>SUB-04</code> <strong>Golden Gate Demolition Corp</strong>: Workers'-Comp cancelled &rarr; License SUSPENDED (§ 7125.2) ($550,000 exposure).
        </li>
      </ul>
    </div>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAY 2 (TUESDAY): 20-GC Cold Outreach Dispatch</span>
        <span class="day-hours">OPERATOR TIME: 2.5 HOURS</span>
      </div>
      <ul class="checklist">
        <li><strong>Step 2.1 — Prospect List:</strong> Filter 20 commercial General Contractors ($3M–$30M volume) with active multi-family/commercial permits in Sacramento, Austin, and Dallas.</li>
        <li><strong>Step 2.2 — Send California Red Tear-Sheet:</strong> Dispatch the exact pre-approved email below to Risk Managers and VPs of Field Operations.</li>
        <li><strong>Step 2.3 — CRM Logging:</strong> Log all 20 outreach emails in your prospect tracker. Set alerts for replies.</li>
      </ul>
      <pre><code>SUBJECT: URGENT CSLB/TDLR Flag: 2 Suspended Subs & $1.82M Uninsured Exposure on Sierra Pacific Active Sites
Marcus —
While running our daily 04:00 AM public contractor registry sweep across California CSLB, Texas TDLR, and Florida DBPR this morning, our Sub Radar engine cross-checked the 40 specialty subcontractors on your active job sites.
We uncovered 2 immediate Stop-Work / Umbrella-Voiding breaches:
1. Sierra Structural Concrete LLC (CSLB #CA-1049281): $25k Surety Bond lapsed -> License SUSPENDED under CA B&P Code § 7071.6 ($420k exposure).
2. Golden Gate Demolition Corp (CSLB #CA-9184420): Workers'-Comp cancelled -> License SUSPENDED under CA B&P Code § 7125.2 ($550k exposure).
Attached is your complete 40-Subcontractor Forensic Liability Audit Packet with live DOM timestamps.
• To unlock the full 40-Sub Audit & Stop-Work Cure Notices today: $149 flat (zero logins or passwords needed).
• To keep our 4 BoardScout bots polling all 40 subs every morning at 04:00 AM: $399/mo retainer.
Reply "UNLOCK" and we will dispatch the cure notices to your project superintendents immediately.</code></pre>
    </div>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAY 3 (WEDNESDAY): Objection Handling &amp; Closing First $149 Audits</span>
        <span class="day-hours">OPERATOR TIME: 1.5 HOURS</span>
      </div>
      <ul class="checklist">
        <li><strong>Step 3.1 — Rapid Response:</strong> Reply to all GC questions within 15 minutes.</li>
        <li><strong>Step 3.2 — Overcoming Objection #1 ("We collect COIs annually"):</strong> <em>"COIs only confirm coverage on the day they were printed. In California, surety bonds and workers'-comp policies lapse mid-project without notifying the GC. State licensing boards suspend licenses automatically by operation of law, voiding your commercial umbrella insurance."</em></li>
        <li><strong>Step 3.3 — Overcoming Objection #2 ("Do you need portal logins?"):</strong> <em>"Zero logins. We never ask for passwords or Procore access. We operate 100% on public sunshine government registries."</em></li>
        <li><strong>Step 3.4 — Payment Collection:</strong> Send Stripe $149 link. Collect <strong>$298.00</strong> cash for the first 2 audits. Ingest client subcontractor rosters.</li>
      </ul>
    </div>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAYS 4–7 (THU–SUN): 24h Audit Delivery, Retainer Seeding &amp; Rest</span>
        <span class="day-hours">OPERATOR TIME: 2.5 HOURS TOTAL</span>
      </div>
      <ul class="checklist">
        <li><strong>Thursday (Day 4 · 1.0h):</strong> Ingest client sub rosters; execute BoardScout and DiffEngine; email branded 40-Sub Liability Audit Packets within 24h.</li>
        <li><strong>Friday (Day 5 · 1.0h):</strong> Host 15-minute executive walkthrough call with client Risk Managers. Review flagged breaches; seed the $399/mo ongoing 04:00 AM monitoring retainer.</li>
        <li><strong>Saturday &amp; Sunday (Days 6–7 · 0.5h):</strong> Review Bot Health console at <code>http://localhost:3000</code>. Verify 0 DOM errors. Rest. Total Week 1 load: <strong>8.5 hours</strong>.</li>
      </ul>
    </div>
  </div>

  <!-- ========================================================================= -->
  <!-- PAGE 5: PART IV — WEEKS 2–4 SCHEDULE & GATE 1 CLEARANCE PLAYBOOK          -->
  <!-- ========================================================================= -->
  <div class="page">
    <div class="header-bar">
      <div>
        <div class="brand">DecaFleet-OS 🚀</div>
        <div class="brand-tag">Part IV: Weeks 2–4 Execution &amp; Gate 1</div>
      </div>
      <div class="doc-meta">
        <div>WEEKS 2–4: DAYS 8 – 30</div>
        <div>PREPARED FOR: <strong>NATALIE & JAY</strong></div>
        <div>TARGET: $4,300+ MRR</div>
      </div>
    </div>

    <h1>Part IV: Weeks 2–4 Step-by-Step Schedule &amp; Gate 1 Clearance</h1>
    <p>
      Natalie & Jay: Week 2 through Week 4 shifts the business from one-time $149 audits into high-margin recurring retainers ($399/mo) and prepares the swarm for Gate 1 clearance.
    </p>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAY 8 (MONDAY, NOV 9): Retainer Agreement Conversion</span>
        <span class="day-hours">OPERATOR TIME: 2.0 HOURS</span>
      </div>
      <ul class="checklist">
        <li><strong>Step 8.1 — Retainer Agreement Dispatch:</strong> Send 1-page agreement + recurring Stripe link ($399/mo, cancel anytime) to the 2 GCs audited in Week 1.</li>
        <li><strong>Step 8.2 — Sign First 2 Retainers:</strong> Close both GCs on $399/mo monitoring. <strong>Base MRR reaches $798.00/mo</strong>.</li>
        <li><strong>Step 8.3 — Queue Roster in BoardScout:</strong> Add their subcontractor rosters to the 04:00 AM automated daily sunshine registry sweep.</li>
      </ul>
    </div>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAYS 9–10 (TUE–WED, NOV 10–11): Texas &amp; Florida Outreach Expansion</span>
        <span class="day-hours">OPERATOR TIME: 3.0 HOURS</span>
      </div>
      <ul class="checklist">
        <li><strong>Step 9.1 — Target 25 New Commercial GCs:</strong> Extract active commercial permit holders in Dallas, Fort Worth, Houston, and Miami.</li>
        <li><strong>Step 9.2 — Dispatch Texas TDLR Tear-Sheets:</strong> Highlight unlicensed trade risks under Tex. Occ. Code § 1305.151 and Tex. Lab. Code § 406.096 (SUB-02 &amp; SUB-05).</li>
        <li><strong>Step 9.3 — Dispatch Florida DBPR Tear-Sheets:</strong> Highlight FL Stat. § 440.107 stop-work orders and officer exemption expirations (SUB-03 &amp; SUB-06).</li>
        <li><strong>Step 9.4 — Close 2 Additional $149 Audits:</strong> Collect <strong>$298.00</strong> entry cash; queue rosters for automated overnight scraping.</li>
      </ul>
    </div>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAYS 11–14 (THU–SUN, NOV 12–15): Daily 04:00 AM Automation &amp; Mid-Sprint Health Check</span>
        <span class="day-hours">OPERATOR TIME: 3.0 HOURS TOTAL</span>
      </div>
      <ul class="checklist">
        <li><strong>Automated 06:00 AM Client Alerts:</strong> Verify active retainers receive daily clean digest or instant breach alerts before job-site gates open.</li>
        <li><strong>Close 3rd Retainer:</strong> Convert 1 previous audit client to $399/mo ongoing retainer. <strong>MRR reaches $1,197.00/mo</strong>.</li>
        <li><strong>Gate 1 Mid-Point Diagnostic Check:</strong> Run <code>npm test</code>. Verify 0 DOM errors over 14 days and weekly load is &lt; 10h/week.</li>
      </ul>
    </div>

    <div class="day-card">
      <div class="day-header">
        <span class="day-title">DAYS 15–30 (NOV 16 – DEC 1): Scaling to 10 Retainers &amp; Gate 1 Clearance</span>
        <span class="day-hours">OPERATOR TIME: 10–12 HOURS / WEEK</span>
      </div>
      <ul class="checklist">
        <li><strong>Outreach Cadence:</strong> Send 15 targeted tear-sheets every Tuesday and Thursday morning.</li>
        <li><strong>Conversion Pipeline:</strong> Close 2–3 new $149 audits per week; maintain 60%+ conversion into $399/mo retainers.</li>
        <li><strong>Day 28 Target:</strong> Reach <strong>10 active paying GC retainers</strong> ($3,990.00 MRR) + entry audits &rarr; <strong>$4,300+ MRR Milestone Achieved</strong>.</li>
        <li><strong>Day 30 Gate 1 Formal Clearance Audit:</strong>
          <br>&bull; &ge; 3 active retainers confirmed (Achieved: 10).
          <br>&bull; 4 consecutive weekly delivery cycles with 0 unhandled DOM selector errors confirmed.
          <br>&bull; Ongoing weekly ops load is &lt; 4 hours/week (Achieved: ~3.5h/week for C1 operations).
        </li>
        <li><strong>December 1, 2026:</strong> Deploy Stage 2 (<strong>P1: Trade Map Desk</strong>) for warm zero-CAC cross-sell (+$449/mo) to the exact same 10 GCs!</li>
      </ul>
    </div>

    <h2>2. Statutory Authority &amp; Legal Citations Summary</h2>
    <table>
      <thead>
        <tr>
          <th>Jurisdiction &amp; Board</th>
          <th>Statutory Citation</th>
          <th>Operation of Law &amp; GC Umbrella Insurance Impact</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>California CSLB</strong></td>
          <td>CA Bus. &amp; Prof. Code <strong>§ 7071.6</strong></td>
          <td>Automatic license suspension immediately upon surety bond lapse. Working with suspended sub voids commercial umbrella coverage.</td>
        </tr>
        <tr>
          <td><strong>California CSLB</strong></td>
          <td>CA Bus. &amp; Prof. Code <strong>§ 7125.2</strong></td>
          <td>Automatic statutory license suspension on workers'-comp cancellation date. Exposes GC to strict liability and Cal/OSHA stop-work order.</td>
        </tr>
        <tr>
          <td><strong>Texas TDLR</strong></td>
          <td>Tex. Occ. Code <strong>§ 1305.151</strong><br>Tex. Lab. Code <strong>§ 406.096</strong></td>
          <td>Unlicensed electrical trade is a Class A misdemeanor. GC becomes statutory employer liable for all medical bills if sub is injured.</td>
        </tr>
        <tr>
          <td><strong>Florida DBPR</strong></td>
          <td>FL Stat. <strong>§ 440.107</strong><br>FL Admin. Code <strong>R. 61G4</strong></td>
          <td>FL Workers' Comp Division issues immediate Stop-Work Orders and penalty equal to 2x avoided premium; shuts down job site.</td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- ========================================================================= -->
  <!-- PAGE 6: PART V — OPERATIONAL ACTION CHECKLIST & SIGN-OFF FOR NATALIE & JAY-->
  <!-- ========================================================================= -->
  <div class="page">
    <div class="header-bar">
      <div>
        <div class="brand">DecaFleet-OS 🚀</div>
        <div class="brand-tag">Part V: Executive Sign-Off &amp; Action Plan</div>
      </div>
      <div class="doc-meta">
        <div>EXECUTIVE SIGN-OFF</div>
        <div>PREPARED FOR: <strong>NATALIE & JAY</strong></div>
        <div>STRICT COMPLIANCE</div>
      </div>
    </div>

    <h1>Part V: Daily Operating Protocols &amp; Founder Sign-Off</h1>
    <p>
      Natalie & Jay: This section outlines your daily operating rhythm and the division of supervisory responsibilities between the two of you to maintain the 20h/week human ceiling.
    </p>

    <h2>1. Daily 15-Minute Supervisory Rhythm</h2>
    <table>
      <thead>
        <tr>
          <th>Time (EST)</th>
          <th>Responsible Founder</th>
          <th>Operational Action &amp; Screen Location</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>07:30 AM</strong></td>
          <td><strong>Jay (Systems &amp; Telemetry)</strong></td>
          <td>
            1. Open Command Center UI at <code>http://localhost:3000</code>.<br>
            2. Check <strong>Bot Health</strong> tab — verify all 10 bots report <code>HEALTHY</code> (0 DOM drift).<br>
            3. Confirm morning 04:00 AM scrape completed across active client rosters.
          </td>
        </tr>
        <tr>
          <td><strong>08:00 AM</strong></td>
          <td><strong>Natalie (Client &amp; Approvals)</strong></td>
          <td>
            1. Check <strong>Approval Gate</strong> tab (<code>ApprovalGateView</code>).<br>
            2. Review staged Tier-2 Co-Sign batch items (CSLB/TDLR breach notices).<br>
            3. Click <strong>"1-Click Batch Approve &amp; Dispatch"</strong> (takes &lt; 60 seconds).
          </td>
        </tr>
        <tr>
          <td><strong>11:30 AM</strong></td>
          <td><strong>Natalie &amp; Jay</strong></td>
          <td>
            1. Review inbound replies to cold tear-sheets.<br>
            2. Send Stripe $149 audit links or $399/mo retainer agreements.<br>
            3. Conduct scheduled 15-minute Zoom debrief calls with paying GCs.
          </td>
        </tr>
        <tr>
          <td><strong>05:00 PM</strong></td>
          <td><strong>Jay (Pipeline &amp; Queue)</strong></td>
          <td>
            1. Ingest newly received subcontractor CSV lists into <code>shared/data/client_rosters/</code>.<br>
            2. Run <code>npm test</code> to ensure unit economics and gate criteria hold true.<br>
            3. Total daily operator time logged: <strong>&le; 90 minutes</strong>.
          </td>
        </tr>
      </tbody>
    </table>

    <h2>2. Founder Sign-Off &amp; Swarm Charter</h2>
    <div class="callout callout-success" style="font-size: 9pt; padding: 14px; margin: 15px 0;">
      <p style="margin-bottom: 8px;"><strong>THE DECAFLEET-OS FOUNDER PLEDGE (NATALIE &amp; JAY):</strong></p>
      <p style="margin-bottom: 6px;">
        1. <strong>Zero-Credential Invariant:</strong> We will never request, accept, or store client passwords, session cookies, or 2FA credentials. We operate 100% on public sunshine government registries.
      </p>
      <p style="margin-bottom: 6px;">
        2. <strong>20h/Week Operator Ceiling:</strong> We will not allow total combined weekly human operations to exceed 20 hours. If hours reach 18.0h, we will halt new outbound pitches and lock expansion gates.
      </p>
      <p style="margin-bottom: 6px;">
        3. <strong>Sequential Gate Discipline:</strong> We will not launch Stage 2 (Trade Map Desk) until Gate 1 is mathematically cleared (&ge; 3 active retainers, 0 DOM errors across 2 cycles, &lt; 4h/week maintenance).
      </p>
      <p style="margin: 0;">
        4. <strong>Jev-AI System One Governance:</strong> All outbound notifications must be adjudicated through the 6-question Jev-AI (<code>jev-latest</code>) gate. Uncertain judgments (&lt; 0.60 confidence) will never be automated.
      </p>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 25px; padding-top: 15px; border-top: 1px solid #cbd5e1;">
      <div style="border: 1px solid #cbd5e1; border-radius: 6px; padding: 15px; background: #f8fafc;">
        <div style="font-size: 8pt; text-transform: uppercase; color: #64748b; font-weight: 700; margin-bottom: 25px;">FOUNDER SIGNATURE:</div>
        <div style="border-bottom: 1px solid #0f172a; margin-bottom: 6px;"></div>
        <div style="font-weight: 800; font-size: 11pt; color: #0f172a;">Natalie</div>
        <div style="font-size: 8pt; color: #64748b;">Co-Founder &amp; Managing Director</div>
        <div style="font-size: 7.5pt; font-family: monospace; color: #94a3b8; margin-top: 4px;">DATE: NOVEMBER 4, 2026</div>
      </div>
      <div style="border: 1px solid #cbd5e1; border-radius: 6px; padding: 15px; background: #f8fafc;">
        <div style="font-size: 8pt; text-transform: uppercase; color: #64748b; font-weight: 700; margin-bottom: 25px;">FOUNDER SIGNATURE:</div>
        <div style="border-bottom: 1px solid #0f172a; margin-bottom: 6px;"></div>
        <div style="font-weight: 800; font-size: 11pt; color: #0f172a;">Jay</div>
        <div style="font-size: 8pt; color: #64748b;">Co-Founder &amp; Technical Director</div>
        <div style="font-size: 7.5pt; font-family: monospace; color: #94a3b8; margin-top: 4px;">DATE: NOVEMBER 4, 2026</div>
      </div>
    </div>
  </div>

</body>
</html>
`;

async function main() {
  console.log('========================================================================================');
  console.log('DECAFLEET-OS // MASTER PRINT PACKAGE GENERATOR');
  console.log('PREPARED FOR: NATALIE & JAY (FOUNDERS & SWARM DIRECTORS)');
  console.log('========================================================================================\n');

  const docsDir = path.resolve(process.cwd(), 'docs');
  const sharedReportsDir = path.resolve(process.cwd(), 'shared/reports');
  fs.mkdirSync(docsDir, { recursive: true });
  fs.mkdirSync(sharedReportsDir, { recursive: true });

  const htmlPath = path.join(docsDir, 'DecaFleet_Master_Print_Package_Natalie_and_Jay.html');
  fs.writeFileSync(htmlPath, HTML_CONTENT, 'utf8');
  console.log(`[HTML Generated] -> ${htmlPath}`);

  // Generate PDF via Microsoft Edge headless
  const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  const pdfDocsPath = path.join(docsDir, 'DecaFleet_Master_Print_Package_Natalie_and_Jay.pdf');
  const pdfSharedPath = path.join(sharedReportsDir, 'DecaFleet_Master_Print_Package_Natalie_and_Jay.pdf');

  if (fs.existsSync(edgePath)) {
    const fileUrl = 'file:///' + htmlPath.replace(/\\/g, '/');
    const cmd = `"${edgePath}" --headless=new --disable-gpu --no-pdf-header-footer --print-to-pdf="${pdfDocsPath}" "${fileUrl}"`;
    
    console.log(`[Executing Edge Headless Print-to-PDF]...`);
    try {
      execSync(cmd, { stdio: 'inherit' });
      if (fs.existsSync(pdfDocsPath)) {
        const stats = fs.statSync(pdfDocsPath);
        console.log(`[PDF Successfully Created] -> ${pdfDocsPath} (${stats.size} bytes)`);
        
        fs.copyFileSync(pdfDocsPath, pdfSharedPath);
        console.log(`[PDF Copied to Shared Reports] -> ${pdfSharedPath}`);
      }
    } catch (err) {
      console.error('Failed to run Edge headless PDF generation:', err);
    }
  } else {
    console.warn(`Microsoft Edge not found at ${edgePath}. HTML print package preserved.`);
  }

  console.log('\n========================================================================================');
  console.log('MASTER PRINT PACKAGE COMPLETE FOR NATALIE & JAY!');
  console.log('========================================================================================');
}

main().catch(console.error);
